<?php
session_start();
   $serveur = "127.0.0.1";
   $login = "root";
   $password = "";
   $connexion = new PDO ("mysql:host=$serveur;dbname=test;charset=utf8", $login, $password);
	
   $_SESSION["id"] = 3;
?>

<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="bigburger.css">
</head>
<body>
<h1 align="center"><b>BURGER DU JOUR :</b><h1>
<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-left" class="left" role="img" viewBox="0 0 448 512"><path fill="currentColor" d="M257.5 445.1l-22.2 22.2c-9.4 9.4-24.6 9.4-33.9 0L7 273c-9.4-9.4-9.4-24.6 0-33.9L201.4 44.7c9.4-9.4 24.6-9.4 33.9 0l22.2 22.2c9.5 9.5 9.3 25-.4 34.3L136.6 216H424c13.3 0 24 10.7 24 24v32c0 13.3-10.7 24-24 24H136.6l120.5 114.8c9.8 9.3 10 24.8.4 34.3z"/></svg>
<div>
<div class="cheese">
<img src="cheese.jpg" height="350px" width="350px"/><br>
<b>Cheese burger</b>
 <h2 class="commandecheese">Commander</h2>
</div>
<div class="fish">
<img src="fish.jpg" height="350px" width="350px"/><br>
<b>Fish burger</b>
 <h2 class="commandefish">Commander</h2>
</div>
<div class="chicken">
<img src="chicken.jpg" height="350px" width="350px"/><br>
<b>Chicken burger</b>
<h2 class="commandechicken">Commander</h2>
</div>
<div class="raclette">
<img src="raclette.jpg" height="350px" width="350px"/><br>
<b>Raclette burger</b>
<h2 class="commanderaclette">Commander</h2>
</div>
</div><br><br><br><br>

<?php 

 if(isset($_POST["commandercheese"])){
	 $steakcheese = htmlspecialchars(intval($_POST["steakcheese"]));
	 $bunscheese = htmlspecialchars(intval($_POST["bunscheese"]));
	 $oignoncheese = htmlspecialchars(intval($_POST["oignoncheese"]));
	 $saladecheese = htmlspecialchars(intval($_POST["saladecheese"]));
	 $tomatecheese = htmlspecialchars(intval($_POST["tomatecheese"]));
	 $cornichoncheese = htmlspecialchars(intval($_POST["cornichoncheese"]));
	 $fromagecheese = htmlspecialchars(intval($_POST["fromagecheese"]));
	 $saucecheese = htmlspecialchars($_POST["saucecheese"]);
	 
	if(!empty($steakcheese) AND !empty($bunscheese) AND !empty($oignoncheese) AND !empty($saladecheese) AND !empty($tomatecheese) AND !empty($cornichoncheese)){
	$ajoutrecette = $connexion->prepare("INSERT INTO stock(steak,buns,oignon,tomate,salade,cornichon,fromage,burgername,prix,date_expedition,sauce,id_user) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
    $ajoutrecette->execute(array($steakcheese,$bunscheese,$oignoncheese,$tomatecheese,$saladecheese,$cornichoncheese,"chedar","cheeseburger","5$",date("Y-m-d"),$saucecheese,$_SESSION["id"]));
		 
		 $insertcommande = $connexion->prepare("INSERT into commande(commande,id_utilisateur,date_expedition) VALUES(?,?,NOW())");
		 $insertcommande->execute(array("Cheeseburger",$_SESSION["id"]));
		 $erreur = "<p class='cmdcheesegood'>Votre commande de cheeseburger a bien été effectué</p><br><br>";		 
	 }else{$erreur = "<p class='cmdcheese'>Veuillez renseigner tous les champs lors de votre commande de cheeseburger</p>";}
	 
 }

?>

<p align="center" class="choix">Choisissez votre burger</p>
<fieldset class="fds">
 <legend>Historique d'ajout des dernières commandes</legend>
  <?php $historique = $connexion->query("SELECT commande,id_utilisateur,date_expedition FROM commande INNER JOIN burgermembre 
  ON commande.id_utilisateur = burgermembre.id WHERE commande.id_utilisateur = ".$_SESSION["id"]." ORDER BY commande.date_expedition DESC");
  $i=7;
   while ($histo = $historique->fetch() AND $i-->1 ){;?>
    <p style="font-size:25px;"><?= $histo ["commande"]." N° ".$i; ?></p>
   <?php } ?>
</fieldset>


<form method="POST">
<div class="preparer">
 <h2 class="h2cheese" align="center">Cheesburger</h2>
 <h2 class="h2fish" align="center">Fish Burger</h2>
 <h2 class="h2chicken" align="center">Chicken Burger</h2>
 <h2 class="h2raclette" align="center">Raclette Burger</h2>
 <div class="container">
 <?php if(isset($erreur)){echo $erreur;}?>
  <div class="cheesetable">
<table>
<tr>
 <td><b>Ingrédient</b></td>
 <td><b>Modifier</b></td>
 <td><b>Stock</b></td>
</tr>
<tr>
 <td><br></td>
</tr>
 <tr>
  <td><label for="steakcheese"><b>steak : </b></td></label>
  <td><input type="number" id="steakcheese"  name="steakcheese" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?php $sommesteak = $connexion->query("SELECT SUM(steak) AS sommesteak FROM stock");
            $steaksomme = $sommesteak->fetch();
            echo $steaksomme["sommesteak"];?></td>
</tr>
<tr>
  <td><label for="bunscheese"><b>buns : </b></td></label>
  <td><input type="number" id="bunscheese"  name="bunscheese" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?php $sommebuns = $connexion->query("SELECT SUM(buns) AS sommebuns FROM stock");
            $bunssomme = $sommebuns->fetch();
            echo $bunssomme["sommebuns"];?></td>
</tr>
<tr>
  <td><label for="saladecheese"><b>salade : </b></td></label>
  <td><input type="number" id="saladecheese" name="saladecheese" class="ingredient" onkeypress="return false"min="0" max="1"/></td>
  <td><?php $sommesalade = $connexion->query("SELECT SUM(salade) AS sommesalade FROM stock");
            $saladesomme = $sommesalade->fetch();
            echo $saladesomme["sommesalade"];?></td>
</tr>
<tr>
  <td><label for="tomatecheese"><b>tomate : </b></td></label>
  <td><input type="number" id="tomatecheese" name="tomatecheese" class="ingredient" onkeypress="return false"min="0"/></td>
  <td><?php $sommetomate = $connexion->query("SELECT SUM(tomate) AS sommetomate FROM stock");
            $tomatesomme = $sommetomate->fetch();
            echo $tomatesomme["sommetomate"];?></td>
</tr>
<tr>
  <td><label for="oignoncheese"><b>oignon : </b></td></label>
  <td><input type="number" id="oignoncheese" name="oignoncheese" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?php $sommeoignon = $connexion->query("SELECT SUM(oignon) AS sommeoignon FROM stock");
            $oignonsomme = $sommeoignon->fetch();
            echo $oignonsomme["sommeoignon"];?></td>
</tr>
<tr>
  <td><label for="cornichon"><b>cornichon : </b></td></label>
  <td><input type="number" id="cornichon" name="cornichoncheese" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?php $sommecornichon = $connexion->query("SELECT SUM(cornichon) AS sommecornichon FROM stock");
            $cornichonsomme = $sommecornichon->fetch();
            echo $cornichonsomme["sommecornichon"];?></td>
</tr>
<tr>
  <td><label for="slc"><b>fromage : </b></td></label>
  <td>
   <select id="slcheese" name="fromagecheese">
    <option value="0">chedar</option>
   </select>
   </td>
   <td></td>
</tr>
<tr>
  <td><label for="slcheese1"><b>Sauce : </b></td></label>
  <td>
   <select id="slc1" name="saucecheese">
    <option value="M">Mayonnaise</option>
    <option value="K">Ketchup</option>
	<option value="M,K">Les deux</option>
   </select>
   </td>
   <td></td>
</tr>
<tr>
 <td>
 <label for="prix"><b>Prix :</b></label></td>
 <td><button id="prix" class="prix" name="prixcheese">5$</button></td>
</tr>
</div>
</table>
<br>
 <input type="submit" class="commande" name="commandercheese" value="Commander"/>
</div>

<?php  if(isset($_POST["commanderchicken"])){
	 $filetdepouletchicken = htmlspecialchars(intval($_POST["filetdepouletchicken"]));
	 $bunschicken = htmlspecialchars(intval($_POST["bunschicken"]));
	 $saladechicken = htmlspecialchars(intval($_POST["saladechicken"]));
	 $tomatechicken = htmlspecialchars(intval($_POST["tomatechicken"]));
	 $fromagechicken = htmlspecialchars($_POST["fromagechicken"]);
	 $saucechicken = htmlspecialchars($_POST["saucechicken"]);
	 $painchicken = htmlspecialchars($_POST["painchicken"]);
	 
	if(!empty($filetdepouletchicken) AND !empty($bunschicken) AND !empty($saladechicken) AND !empty($tomatechicken)){
	$ajoutrecette = $connexion->prepare("INSERT INTO stock(filetdepoulet,buns,tomate,salade,fromage,pain,burgername,prix,date_expedition,sauce,id_user) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
    $ajoutrecette->execute(array($filetdepouletchicken,$bunschicken,$tomatechicken,$saladechicken,$fromagechicken,$painchicken,"chickenburger","5$99",date("Y-m-d"),$saucechicken,$_SESSION["id"]));
		 
		 $insertcommande = $connexion->prepare("INSERT into commande(commande,id_utilisateur,date_expedition) VALUES(?,?,NOW())");
		 $insertcommande->execute(array("ChickenBurger",$_SESSION["id"]));
		 $erreur = "<p class='cmdchickengood'>Votre commande de chickenburger a bien été effectué</p>";		 
	 }else{$erreur = "<p class='cmdchicken'>Veuillez renseigner tous les champs lors de votre commande de Chickenburger</p><br><br>";}
	 
 }?>

<div class="chickentable">
<?php if(isset($erreur)){echo $erreur;}?>
<table>
<tr>
 <td><b>Ingrédient</b></td>
 <td><b>Modifier</b></td>
 <td><b>Stock</b></td>
</tr>
<tr>
 <td><br></td>
</tr>
<tr>
  <td><label for="bunschicken"><b>Buns : </b></td></label>
  <td><input type="number" id="bunschicken"  name="bunschicken" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?= $bunssomme["sommebuns"];?></td>
</tr>
<tr>
  <td><label for="filetdepouletchicken"><b>Filet de poulet : </b></td></label>
  <td><input type="number" id="filetdepouletchicken"  name="filetdepouletchicken" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?php $sommefilet = $connexion->query("SELECT SUM(filetdepoulet) AS sommefilet FROM stock");
            $filetsomme = $sommefilet->fetch();
            echo $filetsomme["sommefilet"];?></td>
</tr>
<tr>
  <td><label for="saladechicken"><b>Salade : </b></td></label>
  <td><input type="number" id="saladechiken"  name="saladechicken" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?= $saladesomme["sommesalade"];?></td>
</tr>
<tr>
  <td><label for="tomatechicken"><b>tomate : </b></td></label>
  <td><input type="number" id="tomatechicken"  name="tomatechicken" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?= $tomatesomme["sommetomate"];?></td>
</tr>
<tr>
 <td><label for="slchicken"><b>Fromage : </b></td></label>
  <td>
   <select id="slchicken" name="fromagechicken">
    <option value="chedar">chedar</option>
	<option value="emmental">Emmemtal</option>
   </select>
   </td>
</tr>
 <td><label for="slchicken1"><b>Sauce : </b></td></label>
  <td>
   <select id="slchicken1" name="saucechicken">
    <option value="Blanche">Blanche</option>
   </select>
  </td>
</tr>
 <td><label for="slchicken2"><b>Pain : </b></td></label>
  <td>
   <select id="slchicken2" name="painchicken">
    <option value="Galette de Pomme de Terre">Galette de Pomme de Terre</option>
   </select>
  </td>
</tr>
<tr>
 <td>
 <label for="prixchicken"><b>Prix :</b></label>
 <td><button id="prixchicken" class="prix" name="prixchicken">5$99</button></td>
 </td>
</tr>
</table>
 <input type="submit" class="commande" name="commanderchicken" value="Commander"/>
</div>

<?php 
 if(isset($_POST["commanderfish"])){
	 $poissonfish = htmlspecialchars(intval($_POST["poisson"]));
	 $bunsfish = htmlspecialchars(intval($_POST["bunsfish"]));
	 $saladefish = htmlspecialchars(intval($_POST["saladefish"]));
	 $tomatefish = htmlspecialchars(intval($_POST["tomatefish"]));
	 $fromagefish = htmlspecialchars($_POST["fromagefish"]);
	 $saucefish = htmlspecialchars($_POST["saucefish"]);
	 
	if(!empty($poissonfish) AND !empty($bunsfish) AND !empty($saladefish) AND !empty($tomatefish)){
	$ajoutrecette = $connexion->prepare("INSERT INTO stock(fish,buns,tomate,salade,fromage,burgername,prix,date_expedition,sauce,id_user) VALUES (?,?,?,?,?,?,?,?,?,?)");
    $ajoutrecette->execute(array($poissonfish,$bunsfish,$tomatefish,$saladefish,$fromagefish,"fishburger","5$99",date("Y-m-d"),$saucefish,$_SESSION["id"]));
		 
		 $insertcommande = $connexion->prepare("INSERT into commande(commande,id_utilisateur,date_expedition) VALUES(?,?,NOW())");
		 $insertcommande->execute(array("Fishburger",$_SESSION["id"]));
		 $erreur = "<p class='cmdfishgood'>Votre commande de fishburger a bien été effectué</p>";		 
	 }else{$erreur = "<p class='cmdfish'>Veuillez renseigner tous les champs lors de votre commande de Fishburger</p><br><br>";}
	 
 }?>

<div class="fishtable">
<?php if(isset($erreur)){echo $erreur;}?>
<table> 
<tr>
 <td><b>Ingrédient</b></td>
 <td><b>Modifier</b></td>
 <td><b>Stock</b></td>
</tr>
<tr>
 <td><br></td>
</tr>
<tr>
  <td><label for="bunsfish"><b>Buns : </b></td></label>
  <td><input type="number" id="bunsfish"  name="bunsfish" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?= $bunssomme["sommebuns"];?></td>
</tr>
<tr>
  <td><label for="poissonfish"><b>Poisson pané : </b></td></label>
  <td><input type="number" id="poissonfish"  name="poisson" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?php $sommefish = $connexion->query("SELECT SUM(fish) AS sommefish FROM stock");
            $fishsomme = $sommefish->fetch();
            echo $fishsomme["sommefish"];?></td>
</tr>
<tr>
  <td><label for="saladefish"><b>Salade : </b></td></label>
  <td><input type="number" id="saladefish"  name="saladefish" class="ingredient" onkeypress="return false" min="0"/></td>  
  <td><?= $saladesomme["sommesalade"];?></td>
</tr>
<tr>
  <td><label for="tomatefish"><b>tomate : </b></td></label>
  <td><input type="number" id="tomatefish"  name="tomatefish" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?= $tomatesomme["sommetomate"];?></td>
</tr>
<tr>
 <td><label for="slcfish"><b>Fromage : </b></td></label>
  <td>
   <select id="slcfish" name="fromagefish">
    <option value="chedar">chedar</option>
	<option value="emmental">Emmemtal</option>
   </select>
   </td>
</tr>
 <td><label for="slcfish1"><b>Sauce : </b></td></label>
  <td>
   <select id="slcfish1" name="saucefish">
    <option value="Sauce aux herbes crémeuse">Sauce aux herbes crémeuse</option>
   </select>
   </td>
</tr>
<tr>
 <td><label for="prixfish"><b>Prix :</b></label></td>
 <td><button id="prixfish" class="prix" name="prixfish">5$99</button></td>
</tr>
</table>
<input type="submit" class="commande" name="commanderfish" value="Commander"/>
</div>
<?php if(isset($_POST["commanderaclette"])){
	 $steakhacheraclette = htmlspecialchars(intval($_POST["steakhache"]));
	 $bunsraclette = htmlspecialchars(intval($_POST["bunsraclette"]));
	 $saladeraclette = htmlspecialchars(intval($_POST["saladeraclette"]));
	 $tomateraclette = htmlspecialchars(intval($_POST["tomateraclette"]));
	 $fromageraclette = htmlspecialchars($_POST["fromageraclette"]);
	 $sauceraclette = htmlspecialchars($_POST["sauceraclette"]);
	 $oignonrougeraclette = htmlspecialchars(intval($_POST["oignonrougeraclette"]));
	 
	if(!empty($steakhacheraclette) AND !empty($bunsraclette) AND !empty($saladeraclette) AND !empty($tomateraclette) AND !empty($oignonrougeraclette)){
	$ajoutrecette = $connexion->prepare("INSERT INTO stock(steakhache,buns,tomate,salade,oignonrouge,fromage,burgername,prix,date_expedition,sauce,id_user) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
    $ajoutrecette->execute(array($steakhacheraclette,$bunsraclette,$tomateraclette,$saladeraclette,$oignonrougeraclette,$fromageraclette,"racletteburger","5$99",date("Y-m-d"),$sauceraclette,$_SESSION["id"]));
		 
		 $insertcommande = $connexion->prepare("INSERT into commande(commande,id_utilisateur,date_expedition) VALUES(?,?,NOW())");
		 $insertcommande->execute(array("Racletteburger",$_SESSION["id"]));
		 $erreur = "<p class='cmdraclettegood'>Votre commande de racletteburger a bien été effectué</p>";		 
	 }else{$erreur = "<p class='cmdraclette'>Veuillez renseigner tous les champs lors de votre commande de Racletteburger</p><br><br>";}
	 
 }?>

<div class="raclettetable">
<?php if(isset($erreur)){echo $erreur;}?>
<table> 
<tr>
 <td><b>Ingrédient</b></td>
 <td><b>Modifier</b></td>
 <td><b>Stock</b></td>
</tr>
<tr>
 <td><br></td>
</tr>
<tr>
  <td><label for="bunsraclette"><b>Buns : </b></td></label>
  <td><input type="number" id="bunsraclette"  name="bunsraclette" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?= $bunssomme["sommebuns"];?></td>
</tr>
<tr>
  <td><label for="steakhache"><b>Steak Haché : </b></td></label>
  <td><input type="number" id="steakhache"  name="steakhache" class="ingredient" onkeypress="return false" min="0"/></td>
<td><?php $sommesteakhache = $connexion->query("SELECT SUM(steak) AS sommesteakhache FROM stock");
            $steakhachesomme = $sommesteakhache->fetch();
            echo $steakhachesomme["sommesteakhache"];?></td>
</tr>
<tr>
  <td><label for="saladeraclette"><b>Salade : </b></td></label>
  <td><input type="number" id="saladeraclette"  name="saladeraclette" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?= $saladesomme["sommesalade"];?></td>
</tr>
<tr>
  <td><label for="tomateraclette"><b>tomate : </b></td></label>
  <td><input type="number" id="tomateraclette"  name="tomateraclette" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?= $tomatesomme["sommetomate"];?><td>
</tr>
<tr>
  <td><label for="oignonraclette"><b>Oignon rouge : </b></td></label>
  <td><input type="number" id="oignonraclette"  name="oignonrougeraclette" class="ingredient" onkeypress="return false" min="0"/></td>
  <td><?php $sommeoignonrouge = $connexion->query("SELECT SUM(oignonrouge) AS sommeoignonrouge FROM stock");
            $oignonrougesomme = $sommeoignonrouge->fetch();
            echo $oignonrougesomme["sommeoignonrouge"];?></td>
</tr>
<tr>
 <td><label for="slcraclette"><b>Fromage : </b></td></label>
  <td>
   <select id="slcraclette" name="fromageraclette">
    <option value="Fromage à raclette">Fromage à raclette</option>
   </select>
   </td>
</tr>
 <td><label for="slcraclette1"><b>Sauce : </b></td></label>
  <td>
   <select id="slcraclette1" name="sauceraclette">
    <option value="Moutarde à l'ancienne">Moutarde à l'ancienne</option>
   </select>
   </td>
</tr>
<tr>
 <td><label for="prixraclette"><b>Prix :</b></label></td>
 <td><button id="prixraclette" class="prix" name="prixraclette">5$99</button></td>
</tr>
</table>
 <input type="submit" class="commande" name="commanderaclette" value="Commander"/>
</div>
</form>
</div><br><br>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 
<script src="bigburger.js"></script>

</body>
</html>
