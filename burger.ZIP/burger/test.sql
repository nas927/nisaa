-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  lun. 27 avr. 2020 à 17:00
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `test`
--

-- --------------------------------------------------------

--
-- Structure de la table `burgermembre`
--

DROP TABLE IF EXISTS `burgermembre`;
CREATE TABLE IF NOT EXISTS `burgermembre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `burgermembre`
--

INSERT INTO `burgermembre` (`id`, `pseudo`) VALUES
(3, 'zahra');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

DROP TABLE IF EXISTS `commande`;
CREATE TABLE IF NOT EXISTS `commande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commande` varchar(255) NOT NULL,
  `id_utilisateur` varchar(255) NOT NULL,
  `date_expedition` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `stock`
--

DROP TABLE IF EXISTS `stock`;
CREATE TABLE IF NOT EXISTS `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(255) NOT NULL DEFAULT 0,
  `steak` varchar(255) NOT NULL DEFAULT '0',
  `filetdepoulet` int(255) DEFAULT NULL,
  `steakhache` varchar(255) NOT NULL DEFAULT '0',
  `fish` varchar(255) NOT NULL DEFAULT '0',
  `buns` varchar(255) NOT NULL DEFAULT '0',
  `salade` varchar(255) NOT NULL DEFAULT '0',
  `tomate` varchar(255) NOT NULL DEFAULT '0',
  `oignon` varchar(255) NOT NULL DEFAULT '0',
  `cornichon` varchar(255) NOT NULL DEFAULT '0',
  `oignonrouge` varchar(255) NOT NULL DEFAULT '0',
  `fromage` varchar(255) NOT NULL DEFAULT '0',
  `pain` varchar(255) DEFAULT NULL,
  `sauce` text DEFAULT NULL,
  `burgername` varchar(255) NOT NULL DEFAULT 'burger',
  `prix` varchar(255) DEFAULT NULL,
  `date_expedition` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
