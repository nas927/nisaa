var nom = document.getElementById("nom");

function nom0(){
  
     nom.style.display = "inline-block";
  
}