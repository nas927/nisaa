var pion = document.getElementById("canvas0");
var contexte = pion.getContext("2d");

var pion1 = document.getElementById("canvas1");
var contexte1 = pion1.getContext("2d");

var pion2 = document.getElementById("canvas2");
var contexte2 = pion2.getContext("2d");

var pion3 = document.getElementById("canvas3");
var contexte3 = pion3.getContext("2d");

var pion4 = document.getElementById("canvas4");
var contexte4 = pion4.getContext("2d");

var pion5 = document.getElementById("canvas5");
var contexte5 = pion5.getContext("2d");

var pion6 = document.getElementById("canvas6");
var contexte6 = pion6.getContext("2d");

var pion7 = document.getElementById("canvas7");
var contexte7 = pion7.getContext("2d");

var pion8 = document.getElementById("canvas8");
var contexte8 = pion8.getContext("2d");

var pion9 = document.getElementById("canvas9");
var contexte9 = pion9.getContext("2d");

var pion10 = document.getElementById("canvas10");
var contexte10 = pion10.getContext("2d");

var pion11 = document.getElementById("canvas11");
var contexte11 = pion11.getContext("2d");

var pion12 = document.getElementById("canvas12");
var contexte12 = pion12.getContext("2d");

var pion13 = document.getElementById("canvas13");
var contexte13 = pion13.getContext("2d");

var pion14 = document.getElementById("canvas14");
var contexte14 = pion14.getContext("2d");

var pion15 = document.getElementById("canvas15");
var contexte15 = pion15.getContext("2d");

var pion16 = document.getElementById("canvas16");
var contexte16 = pion16.getContext("2d");

var pion17 = document.getElementById("canvas17");
var contexte17 = pion17.getContext("2d");

var pion18 = document.getElementById("canvas18");
var contexte18 = pion18.getContext("2d");

var pion19 = document.getElementById("canvas19");
var contexte19 = pion19.getContext("2d");

var pion20 = document.getElementById("canvas20");
var contexte20 = pion20.getContext("2d");

var pion21 = document.getElementById("canvas21");
var contexte21 = pion21.getContext("2d");

var pion22 = document.getElementById("canvas22");
var contexte22 = pion22.getContext("2d");

var pion23 = document.getElementById("canvas23");
var contexte23 = pion23.getContext("2d");


contexte.beginPath();
contexte.fillStyle = "yellow";
contexte.arc(50, 50, 40, 0, 2*Math.PI);
contexte.fill();
contexte.beginPath();
contexte.strokeStyle = "black";
contexte.arc(50, 50, 30, 0, 2*Math.PI);
contexte.stroke();

contexte1.beginPath();
contexte1.fillStyle = "black";
contexte1.arc(50, 50, 40, 0, 2*Math.PI);
contexte1.fill();
contexte1.beginPath();
contexte1.strokeStyle = "white";
contexte1.arc(50, 50, 30, 0, 2*Math.PI);
contexte1.stroke();

contexte2.beginPath();
contexte2.fillStyle = "yellow";
contexte2.arc(50, 50, 40, 0, 2*Math.PI);
contexte2.fill();
contexte2.beginPath();
contexte2.strokeStyle = "black";
contexte2.arc(50, 50, 30, 0, 2*Math.PI);
contexte2.stroke();

contexte3.beginPath();
contexte3.fillStyle = "black";
contexte3.arc(50, 50, 40, 0, 2*Math.PI);
contexte3.fill();
contexte3.beginPath();
contexte3.strokeStyle = "white";
contexte3.arc(50, 50, 30, 0, 2*Math.PI);
contexte3.stroke();

contexte4.beginPath();
contexte4.fillStyle = "yellow";
contexte4.arc(50, 50, 40, 0, 2*Math.PI);
contexte4.fill();
contexte4.beginPath();
contexte4.strokeStyle = "black";
contexte4.arc(50, 50, 30, 0, 2*Math.PI);
contexte4.stroke();

contexte5.beginPath();
contexte5.fillStyle = "black";
contexte5.arc(50, 50, 40, 0, 2*Math.PI);
contexte5.fill();
contexte5.beginPath();
contexte5.strokeStyle = "white";
contexte5.arc(50, 50, 30, 0, 2*Math.PI);
contexte5.stroke();

contexte6.beginPath();
contexte6.fillStyle = "yellow";
contexte6.arc(50, 50, 40, 0, 2*Math.PI);
contexte6.fill();
contexte6.beginPath();
contexte6.strokeStyle = "black";
contexte6.arc(50, 50, 30, 0, 2*Math.PI);
contexte6.stroke();

contexte7.beginPath();
contexte7.fillStyle = "black";
contexte7.arc(50, 50, 40, 0, 2*Math.PI);
contexte7.fill();
contexte7.beginPath();
contexte7.strokeStyle = "white";
contexte7.arc(50, 50, 30, 0, 2*Math.PI);
contexte7.stroke();

contexte8.beginPath();
contexte8.fillStyle = "yellow";
contexte8.arc(50, 50, 40, 0, 2*Math.PI);
contexte8.fill();
contexte8.beginPath();
contexte8.strokeStyle = "black";
contexte8.arc(50, 50, 30, 0, 2*Math.PI);
contexte8.stroke();

contexte9.beginPath();
contexte9.fillStyle = "black";
contexte9.arc(50, 50, 40, 0, 2*Math.PI);
contexte9.fill();
contexte9.beginPath();
contexte9.strokeStyle = "white";
contexte9.arc(50, 50, 30, 0, 2*Math.PI);
contexte9.stroke();

contexte10.beginPath();
contexte10.fillStyle = "yellow";
contexte10.arc(50, 50, 40, 0, 2*Math.PI);
contexte10.fill();
contexte10.beginPath();
contexte10.strokeStyle = "black";
contexte10.arc(50, 50, 30, 0, 2*Math.PI);
contexte10.stroke();

contexte11.beginPath();
contexte11.fillStyle = "black";
contexte11.arc(50, 50, 40, 0, 2*Math.PI);
contexte11.fill();
contexte11.beginPath();
contexte11.strokeStyle = "white";
contexte11.arc(50, 50, 30, 0, 2*Math.PI);
contexte11.stroke();

contexte12.beginPath();
contexte12.fillStyle = "yellow";
contexte12.arc(50, 50, 40, 0, 2*Math.PI);
contexte12.fill();
contexte12.beginPath();
contexte12.strokeStyle = "black";
contexte12.arc(50, 50, 30, 0, 2*Math.PI);
contexte12.stroke();

contexte13.beginPath();
contexte13.fillStyle = "black";
contexte13.arc(50, 50, 40, 0, 2*Math.PI);
contexte13.fill();
contexte13.beginPath();
contexte13.strokeStyle = "white";
contexte13.arc(50, 50, 30, 0, 2*Math.PI);
contexte13.stroke();

contexte14.beginPath();
contexte14.fillStyle = "yellow";
contexte14.arc(50, 50, 40, 0, 2*Math.PI);
contexte14.fill();
contexte14.beginPath();
contexte14.strokeStyle = "black";
contexte14.arc(50, 50, 30, 0, 2*Math.PI);
contexte14.stroke();

contexte15.beginPath();
contexte15.fillStyle = "black";
contexte15.arc(50, 50, 40, 0, 2*Math.PI);
contexte15.fill();
contexte15.beginPath();
contexte15.strokeStyle = "white";
contexte15.arc(50, 50, 30, 0, 2*Math.PI);
contexte15.stroke();

contexte16.beginPath();
contexte16.fillStyle = "yellow";
contexte16.arc(50, 50, 40, 0, 2*Math.PI);
contexte16.fill();
contexte16.beginPath();
contexte16.strokeStyle = "black";
contexte16.arc(50, 50, 30, 0, 2*Math.PI);
contexte16.stroke();

contexte17.beginPath();
contexte17.fillStyle = "black";
contexte17.arc(50, 50, 40, 0, 2*Math.PI);
contexte17.fill();
contexte17.beginPath();
contexte17.strokeStyle = "white";
contexte17.arc(50, 50, 30, 0, 2*Math.PI);
contexte17.stroke();

contexte18.beginPath();
contexte18.fillStyle = "yellow";
contexte18.arc(50, 50, 40, 0, 2*Math.PI);
contexte18.fill();
contexte18.beginPath();
contexte18.strokeStyle = "black";
contexte18.arc(50, 50, 30, 0, 2*Math.PI);
contexte18.stroke();

contexte19.beginPath();
contexte19.fillStyle = "black";
contexte19.arc(50, 50, 40, 0, 2*Math.PI);
contexte19.fill();
contexte19.beginPath();
contexte19.strokeStyle = "white";
contexte19.arc(50, 50, 30, 0, 2*Math.PI);
contexte19.stroke();

contexte20.beginPath();
contexte20.fillStyle = "yellow";
contexte20.arc(50, 50, 40, 0, 2*Math.PI);
contexte20.fill();
contexte20.beginPath();
contexte20.strokeStyle = "black";
contexte20.arc(50, 50, 30, 0, 2*Math.PI);
contexte20.stroke();

contexte21.beginPath();
contexte21.fillStyle = "black";
contexte21.arc(50, 50, 40, 0, 2*Math.PI);
contexte21.fill();
contexte21.beginPath();
contexte21.strokeStyle = "white";
contexte21.arc(50, 50, 30, 0, 2*Math.PI);
contexte21.stroke();

contexte22.beginPath();
contexte22.fillStyle = "yellow";
contexte22.arc(50, 50, 40, 0, 2*Math.PI);
contexte22.fill();
contexte22.beginPath();
contexte22.strokeStyle = "black";
contexte22.arc(50, 50, 30, 0, 2*Math.PI);
contexte22.stroke();

contexte23.beginPath();
contexte23.fillStyle = "black";
contexte23.arc(50, 50, 40, 0, 2*Math.PI);
contexte23.fill();
contexte23.beginPath();
contexte23.strokeStyle = "white";
contexte23.arc(50, 50, 30, 0, 2*Math.PI);
contexte23.stroke();

$("#Alert").click(function(){
	(this).webkitRequestFullscreen();
	(this).mozRequestFullScreen();
	(this).msRequestFullScreen();
	(this).oRequestFullScreen();
});

$(function(){
    $("canvas").draggable({
	    containment: ".contenu",
		revert:true
    });
});

$(function(){
$("canvas").droppable()
});

$("#leave").hide();
$("#replay").hide();

$("#start").click(function(){
	$("img").hide();
	$("#echiquier").hide();
	$("#leave").show();
	$(".ppgd").css("display", "block");
	$("#replay").show();
});

$("#leave").click(function(){
	$("img").show();
	$("#echiquier").show();
	$("#leave").hide();
	$(".ppgd").css("display", "none");
	$("#replay").hide();
});



