<?php
   $serveur = "localhost";
   $login = "Votre nom de base";
   $password = "Mot de passe";
   $connexion = new PDO ("mysql:host=$serveur;dbname=nom de bdd;charset=utf8", $login, $password);
   $connexion -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

 if(isset($_POST["mail"],$_POST["message"])){
	  $mail = htmlspecialchars(trim($_POST["mail"]));
	  $message = htmlspecialchars(trim($_POST["message"]));
	  
	  if(!empty($_POST["mail"]) AND !empty($_POST["message"])){
		  
		  $insmessage = $connexion->prepare("INSERT INTO messagerie(mail,message,date_expedition) VALUES (?,?,?)");
		  $insmessage->execute(array($mail,$message,date('d-m-y H:i:s')));
		  
		  echo "<div style='background-color:green'><b><font color='white'>Message envoyé avec succès</font></b></span>";
}
else{
	      echo "<div style='background-color:red'><b><font color='white'>Veuillez remplir tous les champs</font></b></div>";}
}
 ?>